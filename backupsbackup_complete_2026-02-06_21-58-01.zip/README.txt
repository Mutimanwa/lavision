SAUVEGARDE COMPLÈTE
Date: 2026-02-06 21:58:01
Base de données: gestion_academique_ecole
Tables: 29
Fichiers inclus: 672
Taille BD: 41.12 KB
