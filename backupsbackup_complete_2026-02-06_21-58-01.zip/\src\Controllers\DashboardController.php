<?php
/**
 * Contrôleur du tableau de bord - Version procédurale
 * LaVision - Système de gestion scolaire
 *
 * Ce contrôleur gère l'affichage du tableau de bord principal
 * avec les statistiques et informations importantes.
 */

// require_once __DIR__ . "/BaseController.php";
require_once __DIR__ . "/../Services/auth.php";

/**
 * Vérifie si l'utilisateur est authentifié, sinon redirige vers login
 */
function requireAuth() {
    if (!est_connecte()) {
        $_SESSION['error_message'] = 'Veuillez vous connecter pour accéder à cette page.';
        redirect('login');
    }
}



/**
 * Affiche le tableau de bord principal
 */
function dashboard_index() {
    // Vérifier l'authentification
    requireAuth();

    // Récupérer les données du tableau de bord
    $stats = dashboard_getDashboardStats();
    // $recent_activities = dashboard_getRecentActivities();
    // $upcoming_events = dashboard_getUpcomingEvents();

    // Rendre la vue du tableau de bord

    render('dashboard/index', [
        'stats' => $stats,
        // 'recent_activities' => $recent_activities,
        // 'upcoming_events' => $upcoming_events,
        'page_title' => 'Tableau de bord'
    ]);
}

/**
 * Récupère les statistiques du tableau de bord
 */
function dashboard_getDashboardStats() {
    $db = get_db_connection();

    try {
        // Statistiques des élèves
        $total_eleves = $db->query("SELECT COUNT(*) as total FROM eleves WHERE statut_etudiant = 'actif'")->fetch()['total'] ?? 0;
        $eleves_nouveaux = $db->query("SELECT COUNT(*) as total FROM eleves WHERE DATE(date_creation) >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)")->fetch()['total'] ?? 0;

        // Statistiques du personnel
        $total_personnel = $db->query("SELECT COUNT(*) as total FROM professeurs WHERE statut = 'actif'")->fetch()['total'] ?? 0;

        // Statistiques financières
        $paiements_mois = $db->query("SELECT SUM(montant_paye) as total FROM paiements WHERE DATE(date_paiement) >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)")->fetch()['total'] ?? 0;

        // Statistiques académiques
        $total_classes = $db->query("SELECT COUNT(*) as total FROM classes WHERE statut = 'actif' ")->fetch()['total'] ?? 0;

        return [
            'eleves' => [
                'total' => $total_eleves,
                'nouveaux' => $eleves_nouveaux
            ],
            'personnel' => [
                'total' => $total_personnel
            ],
            'finances' => [
                'paiements_mois' => $paiements_mois
            ],
            'academique' => [
                'classes' => $total_classes
            ]
        ];
    } catch (Exception $e) {
        logAction('Erreur récupération stats dashboard', $e->getMessage());
        return [
            'eleves' => ['total' => 0, 'nouveaux' => 0],
            'personnel' => ['total' => 0],
            'finances' => ['paiements_mois' => 0],
            'academique' => ['classes' => 0]
        ];
    }
}

/**
 * Récupère les activités récentes
 */
// function dashboard_getRecentActivities() {
//     $db = get_db_connection();

//     try {
//         $query = "SELECT a.*, u.nom, u.prenom
//                  FROM logs a
//                  LEFT JOIN utilisateurs u ON a.id_utilisateur = u.id
//                  ORDER BY a.created_at DESC
//                  LIMIT 10";
//         $stmt = $db->prepare($query);
//         $stmt->execute();
//         return $stmt->fetchAll();
//     } catch (Exception $e) {
//         logAction('Erreur récupération activités récentes', $e->getMessage());
//         return [];
//     }
// }

/**
 * Récupère les événements à venir
 */
// function dashboard_getUpcomingEvents() {
//     $db = get_db_connection();

//     try {
//         $query = "SELECT * FROM evenements
//                  WHERE date_evenement >= CURDATE()
//                  ORDER BY date_evenement ASC
//                  LIMIT 5";
//         $stmt = $db->prepare($query);
//         $stmt->execute();
//         return $stmt->fetchAll();
//     } catch (Exception $e) {
//         logAction('Erreur récupération événements', $e->getMessage());
//         return [];
//     }
// }
