SAUVEGARDE COMPLÈTE
Date: 2026-02-06 22:00:20
Base de données: gestion_academique_ecole
Tables: 29
Fichiers inclus: 0
Taille BD: 41.72 KB
