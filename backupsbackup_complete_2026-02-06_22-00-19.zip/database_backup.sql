-- Backup créé le: 2026-02-06 22:00:20
-- Base de données: gestion_academique_ecole
SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS=0;

--
-- Structure de la table `absences`
--
DROP TABLE IF EXISTS `absences`;
CREATE TABLE `absences` (
  `absence_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `eleve_id` bigint(20) NOT NULL,
  `date_absence` date NOT NULL,
  `matiere_id` bigint(20) DEFAULT NULL,
  `periode_journee` enum('matin','aprem','journee') DEFAULT 'journee',
  `justifiee` tinyint(1) DEFAULT 0,
  `motif` varchar(255) DEFAULT NULL,
  `justificatif` varchar(255) DEFAULT NULL,
  `enregistre_par` bigint(20) NOT NULL,
  `date_creation` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`absence_id`),
  KEY `matiere_id` (`matiere_id`),
  KEY `enregistre_par` (`enregistre_par`),
  KEY `idx_absence_eleve` (`eleve_id`),
  KEY `idx_absence_date` (`date_absence`),
  CONSTRAINT `absences_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`eleve_id`) ON DELETE CASCADE,
  CONSTRAINT `absences_ibfk_2` FOREIGN KEY (`matiere_id`) REFERENCES `matieres` (`matiere_id`) ON DELETE SET NULL,
  CONSTRAINT `absences_ibfk_3` FOREIGN KEY (`enregistre_par`) REFERENCES `user_admins` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `absences`
--
--
-- Structure de la table `admissions`
--
DROP TABLE IF EXISTS `admissions`;
CREATE TABLE `admissions` (
  `admission_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `eleve_id` bigint(20) NOT NULL,
  `class_id` bigint(20) NOT NULL,
  `annee_id` bigint(20) NOT NULL,
  `admis_par` bigint(20) DEFAULT NULL,
  `date_admission` datetime DEFAULT current_timestamp(),
  `statut_admission` enum('en_attente','approuve','rejete','liste_attente') DEFAULT 'en_attente',
  `frais_inscription` decimal(10,2) DEFAULT 0.00,
  `frais_payes` decimal(10,2) DEFAULT 0.00,
  `date_limite_paiement` date DEFAULT NULL,
  `notes_entretien` text DEFAULT NULL,
  `decision_comite` text DEFAULT NULL,
  `date_decision` date DEFAULT NULL,
  PRIMARY KEY (`admission_id`),
  KEY `annee_id` (`annee_id`),
  KEY `admis_par` (`admis_par`),
  KEY `idx_admission_eleve` (`eleve_id`),
  KEY `idx_admission_classe` (`class_id`),
  KEY `idx_admission_statut` (`statut_admission`),
  CONSTRAINT `admissions_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`eleve_id`) ON DELETE CASCADE,
  CONSTRAINT `admissions_ibfk_2` FOREIGN KEY (`class_id`) REFERENCES `classes` (`class_id`),
  CONSTRAINT `admissions_ibfk_3` FOREIGN KEY (`annee_id`) REFERENCES `annees_scolaire` (`annee_id`),
  CONSTRAINT `admissions_ibfk_4` FOREIGN KEY (`admis_par`) REFERENCES `user_admins` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `admissions`
--
--
-- Structure de la table `annees_scolaire`
--
DROP TABLE IF EXISTS `annees_scolaire`;
CREATE TABLE `annees_scolaire` (
  `annee_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `annee_libelle` varchar(20) NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `statut` enum('active','inactive') DEFAULT 'active',
  `date_creation` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`annee_id`),
  UNIQUE KEY `annee_libelle` (`annee_libelle`),
  CONSTRAINT `chk_dates` CHECK (`date_fin` > `date_debut`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `annees_scolaire`
--
INSERT INTO `annees_scolaire` (`annee_id`, `annee_libelle`, `date_debut`, `date_fin`, `statut`, `date_creation`) VALUES ('1', '2024-2025', '2024-09-01', '2025-06-30', 'inactive', '2026-01-23 15:22:56');
INSERT INTO `annees_scolaire` (`annee_id`, `annee_libelle`, `date_debut`, `date_fin`, `statut`, `date_creation`) VALUES ('2', '2025-2026', '2025-09-01', '2026-06-30', 'active', '2026-01-23 15:22:56');

--
-- Structure de la table `backup_logs`
--
DROP TABLE IF EXISTS `backup_logs`;
CREATE TABLE `backup_logs` (
  `backup_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type_backup` enum('complete','database','files') DEFAULT 'complete',
  `fichier` varchar(255) NOT NULL,
  `taille` bigint(20) DEFAULT NULL,
  `statut` enum('success','failed','pending') DEFAULT 'pending',
  `erreur_message` text DEFAULT NULL,
  `execute_par` bigint(20) DEFAULT NULL,
  `date_execution` datetime DEFAULT current_timestamp(),
  `date_prochaine` datetime DEFAULT NULL,
  PRIMARY KEY (`backup_id`),
  KEY `execute_par` (`execute_par`),
  KEY `idx_backup_date` (`date_execution`),
  KEY `idx_backup_statut` (`statut`),
  CONSTRAINT `backup_logs_ibfk_1` FOREIGN KEY (`execute_par`) REFERENCES `user_admins` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `backup_logs`
--
INSERT INTO `backup_logs` (`backup_id`, `type_backup`, `fichier`, `taille`, `statut`, `erreur_message`, `execute_par`, `date_execution`, `date_prochaine`) VALUES ('1', '', 'backup_2026-02-05_07-17-26.sql', '7041088', 'success', NULL, NULL, '2026-02-05 08:17:26', NULL);
INSERT INTO `backup_logs` (`backup_id`, `type_backup`, `fichier`, `taille`, `statut`, `erreur_message`, `execute_par`, `date_execution`, `date_prochaine`) VALUES ('2', '', 'backup_2026-02-06_21-17-01.sql', NULL, 'pending', NULL, NULL, '2026-02-06 22:17:01', NULL);
INSERT INTO `backup_logs` (`backup_id`, `type_backup`, `fichier`, `taille`, `statut`, `erreur_message`, `execute_par`, `date_execution`, `date_prochaine`) VALUES ('3', '', 'backup_2026-02-06_21-17-51.sql', NULL, 'failed', 'Type de sauvegarde inconnu', NULL, '2026-02-06 22:17:51', NULL);
INSERT INTO `backup_logs` (`backup_id`, `type_backup`, `fichier`, `taille`, `statut`, `erreur_message`, `execute_par`, `date_execution`, `date_prochaine`) VALUES ('4', 'complete', 'backup_complete_2026-02-06_21-30-41.zip', NULL, 'pending', NULL, NULL, '2026-02-06 22:30:41', NULL);
INSERT INTO `backup_logs` (`backup_id`, `type_backup`, `fichier`, `taille`, `statut`, `erreur_message`, `execute_par`, `date_execution`, `date_prochaine`) VALUES ('5', 'complete', 'backup_complete_2026-02-06_21-31-11.zip', NULL, 'failed', 'Échec sauvegarde BD: Échec de mysqldump (code: 1)', NULL, '2026-02-06 22:31:11', NULL);
INSERT INTO `backup_logs` (`backup_id`, `type_backup`, `fichier`, `taille`, `statut`, `erreur_message`, `execute_par`, `date_execution`, `date_prochaine`) VALUES ('6', 'complete', 'backup_complete_2026-02-06_21-33-55.zip', NULL, 'failed', 'Échec sauvegarde BD: Échec de mysqldump (code: 1)', NULL, '2026-02-06 22:33:55', NULL);
INSERT INTO `backup_logs` (`backup_id`, `type_backup`, `fichier`, `taille`, `statut`, `erreur_message`, `execute_par`, `date_execution`, `date_prochaine`) VALUES ('7', 'complete', 'backup_complete_2026-02-06_21-47-17.zip', NULL, 'pending', NULL, NULL, '2026-02-06 22:47:17', NULL);
INSERT INTO `backup_logs` (`backup_id`, `type_backup`, `fichier`, `taille`, `statut`, `erreur_message`, `execute_par`, `date_execution`, `date_prochaine`) VALUES ('8', 'complete', 'backup_complete_2026-02-06_21-49-05.zip', NULL, 'pending', NULL, NULL, '2026-02-06 22:49:05', NULL);
INSERT INTO `backup_logs` (`backup_id`, `type_backup`, `fichier`, `taille`, `statut`, `erreur_message`, `execute_par`, `date_execution`, `date_prochaine`) VALUES ('9', 'complete', 'backup_complete_2026-02-06_21-49-44.zip', NULL, 'failed', 'SQLSTATE[42S22]: Column not found: 1054 Unknown column \'chemin_fichier\' in \'field list\'', NULL, '2026-02-06 22:49:44', NULL);
INSERT INTO `backup_logs` (`backup_id`, `type_backup`, `fichier`, `taille`, `statut`, `erreur_message`, `execute_par`, `date_execution`, `date_prochaine`) VALUES ('10', 'complete', 'backup_complete_2026-02-06_21-53-10.zip', NULL, 'failed', 'SQLSTATE[42000]: Syntax error or access violation: 1064 You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near \'WHERE backup_id = ?\' at line 1', NULL, '2026-02-06 22:53:10', NULL);
INSERT INTO `backup_logs` (`backup_id`, `type_backup`, `fichier`, `taille`, `statut`, `erreur_message`, `execute_par`, `date_execution`, `date_prochaine`) VALUES ('11', 'complete', 'C:\\xampp\\htdocs\\lavision\\app\\src\\Models/../backups/backup_complete_2026-02-06_21-54-57.zip', '11573779', 'success', NULL, NULL, '2026-02-06 22:54:57', NULL);
INSERT INTO `backup_logs` (`backup_id`, `type_backup`, `fichier`, `taille`, `statut`, `erreur_message`, `execute_par`, `date_execution`, `date_prochaine`) VALUES ('12', 'complete', 'C:\\xampp\\htdocs\\lavision\\app/backupsbackup_complete_2026-02-06_21-58-01.zip', '5812155', 'success', NULL, NULL, '2026-02-06 22:58:01', NULL);
INSERT INTO `backup_logs` (`backup_id`, `type_backup`, `fichier`, `taille`, `statut`, `erreur_message`, `execute_par`, `date_execution`, `date_prochaine`) VALUES ('13', 'complete', 'backup_complete_2026-02-06_21-59-12.zip', NULL, 'pending', NULL, NULL, '2026-02-06 22:59:12', NULL);
INSERT INTO `backup_logs` (`backup_id`, `type_backup`, `fichier`, `taille`, `statut`, `erreur_message`, `execute_par`, `date_execution`, `date_prochaine`) VALUES ('14', 'complete', 'backup_complete_2026-02-06_22-00-19.zip', NULL, 'pending', NULL, NULL, '2026-02-06 23:00:19', NULL);

--
-- Structure de la table `caisse_sessions`
--
DROP TABLE IF EXISTS `caisse_sessions`;
CREATE TABLE `caisse_sessions` (
  `session_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `caissier_id` bigint(20) NOT NULL,
  `montant_ouverture` decimal(10,2) NOT NULL,
  `montant_fermeture` decimal(10,2) DEFAULT NULL,
  `montant_theorique` decimal(10,2) DEFAULT NULL,
  `ecart` decimal(10,2) DEFAULT NULL,
  `observations` text DEFAULT NULL,
  `date_ouverture` datetime NOT NULL,
  `date_fermeture` datetime DEFAULT NULL,
  `statut` enum('ouverte','fermee') DEFAULT 'ouverte',
  PRIMARY KEY (`session_id`),
  KEY `idx_session_caissier` (`caissier_id`),
  KEY `idx_session_statut` (`statut`),
  CONSTRAINT `caisse_sessions_ibfk_1` FOREIGN KEY (`caissier_id`) REFERENCES `user_admins` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `caisse_sessions`
--
--
-- Structure de la table `classes`
--
DROP TABLE IF EXISTS `classes`;
CREATE TABLE `classes` (
  `class_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `niveau_id` bigint(20) NOT NULL,
  `section_id` bigint(20) DEFAULT NULL,
  `libelle` varchar(100) NOT NULL,
  `annee_id` bigint(20) NOT NULL,
  `capacite_max` int(11) DEFAULT 30,
  `salle` varchar(50) DEFAULT NULL,
  `tuteur_id` bigint(20) DEFAULT NULL,
  `statut` enum('active','inactive') DEFAULT 'active',
  `date_creation` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`class_id`),
  KEY `section_id` (`section_id`),
  KEY `idx_classe_annee` (`annee_id`),
  KEY `idx_classe_niveau` (`niveau_id`),
  KEY `fk_classe_tuteur` (`tuteur_id`),
  CONSTRAINT `classes_ibfk_1` FOREIGN KEY (`niveau_id`) REFERENCES `niveau` (`niveau_id`),
  CONSTRAINT `classes_ibfk_2` FOREIGN KEY (`section_id`) REFERENCES `sections` (`section_id`) ON DELETE SET NULL,
  CONSTRAINT `classes_ibfk_3` FOREIGN KEY (`annee_id`) REFERENCES `annees_scolaire` (`annee_id`),
  CONSTRAINT `fk_classe_tuteur` FOREIGN KEY (`tuteur_id`) REFERENCES `professeurs` (`professeur_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `classes`
--
INSERT INTO `classes` (`class_id`, `niveau_id`, `section_id`, `libelle`, `annee_id`, `capacite_max`, `salle`, `tuteur_id`, `statut`, `date_creation`) VALUES ('1', '1', '2', 'test', '2', '30', NULL, '2', 'active', '2026-01-26 04:31:25');

--
-- Structure de la table `eleves`
--
DROP TABLE IF EXISTS `eleves`;
CREATE TABLE `eleves` (
  `eleve_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `matricule` varchar(30) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `post_nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `date_naissance` date NOT NULL,
  `lieu_naissance` varchar(100) DEFAULT NULL,
  `genre` enum('M','F','Autre') DEFAULT 'Autre',
  `nationalite` varchar(50) DEFAULT 'Congolaise',
  `telephone` varchar(20) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `groupe_sanguin` varchar(5) DEFAULT NULL,
  `allergies` text DEFAULT NULL,
  `statut_etudiant` enum('en_attente','actif','suspendu','desiste') DEFAULT 'en_attente',
  `date_inscription` date DEFAULT NULL,
  `date_creation` datetime DEFAULT current_timestamp(),
  `date_modif` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`eleve_id`),
  UNIQUE KEY `matricule` (`matricule`),
  KEY `idx_eleve_matricule` (`matricule`),
  KEY `idx_eleve_statut` (`statut_etudiant`),
  KEY `idx_eleve_nom` (`nom`,`prenom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `eleves`
--
--
-- Structure de la table `emploi_du_temps`
--
DROP TABLE IF EXISTS `emploi_du_temps`;
CREATE TABLE `emploi_du_temps` (
  `edt_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `class_id` bigint(20) NOT NULL,
  `matiere_id` bigint(20) NOT NULL,
  `professeur_id` bigint(20) NOT NULL,
  `jour_semaine` enum('Lundi','Mardi','Mercredi','Jeudi','Vendredi','Samedi') NOT NULL,
  `heure_debut` time NOT NULL,
  `heure_fin` time NOT NULL,
  `salle` varchar(50) DEFAULT NULL,
  `type_cours` enum('cours','td','tp','examen') DEFAULT 'cours',
  `annee_id` bigint(20) NOT NULL,
  `periode` enum('trimestre1','trimestre2','trimestre3') DEFAULT 'trimestre1',
  `date_debut` date DEFAULT NULL,
  `date_fin` date DEFAULT NULL,
  `statut` enum('actif','suspendu') DEFAULT 'actif',
  `date_creation` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`edt_id`),
  UNIQUE KEY `uk_edt_unique` (`class_id`,`jour_semaine`,`heure_debut`,`annee_id`,`periode`),
  KEY `matiere_id` (`matiere_id`),
  KEY `annee_id` (`annee_id`),
  KEY `idx_edt_classe` (`class_id`),
  KEY `idx_edt_professeur` (`professeur_id`),
  CONSTRAINT `emploi_du_temps_ibfk_1` FOREIGN KEY (`class_id`) REFERENCES `classes` (`class_id`) ON DELETE CASCADE,
  CONSTRAINT `emploi_du_temps_ibfk_2` FOREIGN KEY (`matiere_id`) REFERENCES `matieres` (`matiere_id`) ON DELETE CASCADE,
  CONSTRAINT `emploi_du_temps_ibfk_3` FOREIGN KEY (`professeur_id`) REFERENCES `professeurs` (`professeur_id`) ON DELETE CASCADE,
  CONSTRAINT `emploi_du_temps_ibfk_4` FOREIGN KEY (`annee_id`) REFERENCES `annees_scolaire` (`annee_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `emploi_du_temps`
--
INSERT INTO `emploi_du_temps` (`edt_id`, `class_id`, `matiere_id`, `professeur_id`, `jour_semaine`, `heure_debut`, `heure_fin`, `salle`, `type_cours`, `annee_id`, `periode`, `date_debut`, `date_fin`, `statut`, `date_creation`) VALUES ('2', '1', '1', '1', 'Lundi', '08:00:00', '09:00:00', NULL, 'cours', '2', 'trimestre1', NULL, NULL, 'actif', '2026-01-26 06:29:39');

--
-- Structure de la table `login_attempts`
--
DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE `login_attempts` (
  `attempt_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `identifiant` varchar(50) NOT NULL,
  `success` tinyint(1) DEFAULT 0,
  `reason` varchar(255) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `attempt_time` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`attempt_id`),
  KEY `idx_login_attempts_ip` (`ip_address`),
  KEY `idx_login_attempts_time` (`attempt_time`),
  KEY `idx_login_attempts_success` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `login_attempts`
--
--
-- Structure de la table `logs`
--
DROP TABLE IF EXISTS `logs`;
CREATE TABLE `logs` (
  `log_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `niveau_log` enum('info','warning','error','security') DEFAULT 'info',
  `categorie` varchar(50) NOT NULL,
  `action` varchar(255) NOT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `date_action` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`log_id`),
  KEY `idx_logs_user` (`user_id`),
  KEY `idx_logs_date` (`date_action`),
  KEY `idx_logs_categorie` (`categorie`),
  KEY `idx_logs_niveau` (`niveau_log`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `logs`
--
--
-- Structure de la table `matieres`
--
DROP TABLE IF EXISTS `matieres`;
CREATE TABLE `matieres` (
  `matiere_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `code_matiere` varchar(20) NOT NULL,
  `nom_matiere` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `coefficient` decimal(3,2) DEFAULT 1.00,
  `niveau_id` bigint(20) DEFAULT NULL,
  `couleur` varchar(7) DEFAULT '#2ecc71',
  `heures_semaine` int(11) DEFAULT 4,
  `est_obligatoire` tinyint(1) DEFAULT 1,
  `date_creation` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`matiere_id`),
  UNIQUE KEY `code_matiere` (`code_matiere`),
  KEY `idx_matiere_code` (`code_matiere`),
  KEY `idx_matiere_niveau` (`niveau_id`),
  CONSTRAINT `matieres_ibfk_1` FOREIGN KEY (`niveau_id`) REFERENCES `niveau` (`niveau_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `matieres`
--
INSERT INTO `matieres` (`matiere_id`, `code_matiere`, `nom_matiere`, `description`, `coefficient`, `niveau_id`, `couleur`, `heures_semaine`, `est_obligatoire`, `date_creation`) VALUES ('1', 'MATH', 'Mathematique', 'Cours de mathematique', '1.00', '1', '#2ecc71', '4', '1', '2026-01-24 04:15:09');

--
-- Structure de la table `niveau`
--
DROP TABLE IF EXISTS `niveau`;
CREATE TABLE `niveau` (
  `niveau_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nom_niveau` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `ordre_affichage` int(11) DEFAULT 0,
  `date_creation` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`niveau_id`),
  UNIQUE KEY `nom_niveau` (`nom_niveau`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `niveau`
--
INSERT INTO `niveau` (`niveau_id`, `nom_niveau`, `description`, `ordre_affichage`, `date_creation`) VALUES ('1', '7e année', 'Première année du secondaire', '1', '2026-01-23 15:22:58');
INSERT INTO `niveau` (`niveau_id`, `nom_niveau`, `description`, `ordre_affichage`, `date_creation`) VALUES ('2', '8e année', 'Deuxième année du secondaire', '2', '2026-01-23 15:22:58');
INSERT INTO `niveau` (`niveau_id`, `nom_niveau`, `description`, `ordre_affichage`, `date_creation`) VALUES ('3', '9e année', 'Troisième année du secondaire', '3', '2026-01-23 15:22:58');
INSERT INTO `niveau` (`niveau_id`, `nom_niveau`, `description`, `ordre_affichage`, `date_creation`) VALUES ('4', '10e année', 'Première année du secondaire supérieur', '4', '2026-01-23 15:22:58');
INSERT INTO `niveau` (`niveau_id`, `nom_niveau`, `description`, `ordre_affichage`, `date_creation`) VALUES ('5', '11e année', 'Deuxième année du secondaire supérieur', '5', '2026-01-23 15:22:58');
INSERT INTO `niveau` (`niveau_id`, `nom_niveau`, `description`, `ordre_affichage`, `date_creation`) VALUES ('6', '12e année', 'Troisième année du secondaire supérieur', '6', '2026-01-23 15:22:58');

--
-- Structure de la table `notes`
--
DROP TABLE IF EXISTS `notes`;
CREATE TABLE `notes` (
  `note_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `eleve_id` bigint(20) NOT NULL,
  `matiere_id` bigint(20) NOT NULL,
  `type_evaluation` enum('Devoir','Examen','Projet','Participation','Composition') NOT NULL,
  `note` decimal(5,2) NOT NULL CHECK (`note` >= 0 and `note` <= 20),
  `coefficient` decimal(3,2) DEFAULT 1.00,
  `date_evaluation` date NOT NULL,
  `annee_id` bigint(20) NOT NULL,
  `periode` enum('trimestre1','trimestre2','trimestre3') NOT NULL,
  `professeur_id` bigint(20) DEFAULT NULL,
  `remarques` text DEFAULT NULL,
  `est_rectifiee` tinyint(1) DEFAULT 0,
  `note_rectifiee` decimal(5,2) DEFAULT NULL,
  `date_creation` datetime DEFAULT current_timestamp(),
  `modifie_par` bigint(20) DEFAULT NULL,
  `date_modif` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`note_id`),
  UNIQUE KEY `uk_note_unique` (`eleve_id`,`matiere_id`,`type_evaluation`,`date_evaluation`,`periode`,`annee_id`),
  KEY `annee_id` (`annee_id`),
  KEY `professeur_id` (`professeur_id`),
  KEY `modifie_par` (`modifie_par`),
  KEY `idx_note_eleve` (`eleve_id`),
  KEY `idx_note_matiere` (`matiere_id`),
  KEY `idx_note_periode` (`periode`,`annee_id`),
  CONSTRAINT `notes_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`eleve_id`) ON DELETE CASCADE,
  CONSTRAINT `notes_ibfk_2` FOREIGN KEY (`matiere_id`) REFERENCES `matieres` (`matiere_id`) ON DELETE CASCADE,
  CONSTRAINT `notes_ibfk_3` FOREIGN KEY (`annee_id`) REFERENCES `annees_scolaire` (`annee_id`) ON DELETE CASCADE,
  CONSTRAINT `notes_ibfk_4` FOREIGN KEY (`professeur_id`) REFERENCES `professeurs` (`professeur_id`) ON DELETE SET NULL,
  CONSTRAINT `notes_ibfk_5` FOREIGN KEY (`modifie_par`) REFERENCES `user_admins` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `notes`
--
--
-- Structure de la table `paiement_journal`
--
DROP TABLE IF EXISTS `paiement_journal`;
CREATE TABLE `paiement_journal` (
  `journal_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `paiement_id` bigint(20) NOT NULL,
  `montant` decimal(10,2) NOT NULL,
  `mode_paiement` enum('Espece','Virement','Cheque','Mobile','Carte') NOT NULL,
  `reference_banque` varchar(100) DEFAULT NULL,
  `caissier_id` bigint(20) NOT NULL,
  `notes` text DEFAULT NULL,
  `date_operation` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`journal_id`),
  KEY `caissier_id` (`caissier_id`),
  KEY `idx_journal_paiement` (`paiement_id`),
  KEY `idx_journal_date` (`date_operation`),
  CONSTRAINT `paiement_journal_ibfk_1` FOREIGN KEY (`paiement_id`) REFERENCES `paiements` (`paiement_id`) ON DELETE CASCADE,
  CONSTRAINT `paiement_journal_ibfk_2` FOREIGN KEY (`caissier_id`) REFERENCES `user_admins` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `paiement_journal`
--
--
-- Structure de la table `paiements`
--
DROP TABLE IF EXISTS `paiements`;
CREATE TABLE `paiements` (
  `paiement_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `reference` varchar(50) NOT NULL,
  `eleve_id` bigint(20) NOT NULL,
  `annee_id` bigint(20) NOT NULL,
  `type_frais` enum('Inscription','Scolarite','Activite','Transport','Uniforme','Autre') NOT NULL,
  `libelle` varchar(255) NOT NULL,
  `montant_total` decimal(10,2) NOT NULL CHECK (`montant_total` > 0),
  `montant_paye` decimal(10,2) DEFAULT 0.00 CHECK (`montant_paye` >= 0),
  `reste_a_payer` decimal(10,2) GENERATED ALWAYS AS (`montant_total` - `montant_paye`) STORED,
  `date_echeance` date DEFAULT NULL,
  `date_paiement` date DEFAULT NULL,
  `mode_paiement` enum('Espece','Virement','Cheque','Mobile','Carte') DEFAULT 'Espece',
  `statut` enum('impaye','partiel','paye','annule') DEFAULT 'impaye',
  `banque` varchar(100) DEFAULT NULL,
  `reference_banque` varchar(100) DEFAULT NULL,
  `caissier_id` bigint(20) NOT NULL,
  `notes` text DEFAULT NULL,
  `date_creation` datetime DEFAULT current_timestamp(),
  `date_modif` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`paiement_id`),
  UNIQUE KEY `reference` (`reference`),
  KEY `annee_id` (`annee_id`),
  KEY `caissier_id` (`caissier_id`),
  KEY `idx_paiement_eleve` (`eleve_id`),
  KEY `idx_paiement_statut` (`statut`),
  KEY `idx_paiement_reference` (`reference`),
  KEY `idx_paiement_date` (`date_creation`),
  CONSTRAINT `paiements_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`eleve_id`),
  CONSTRAINT `paiements_ibfk_2` FOREIGN KEY (`annee_id`) REFERENCES `annees_scolaire` (`annee_id`),
  CONSTRAINT `paiements_ibfk_3` FOREIGN KEY (`caissier_id`) REFERENCES `user_admins` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `paiements`
--
--
-- Structure de la table `parametres`
--
DROP TABLE IF EXISTS `parametres`;
CREATE TABLE `parametres` (
  `parametre_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cle` varchar(100) NOT NULL,
  `valeur` text DEFAULT NULL,
  `type` enum('string','integer','boolean','json','array') DEFAULT 'string',
  `categorie` varchar(50) DEFAULT 'general',
  `description` text DEFAULT NULL,
  `modifiable` tinyint(1) DEFAULT 1,
  `date_creation` datetime DEFAULT current_timestamp(),
  `date_modif` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`parametre_id`),
  UNIQUE KEY `cle` (`cle`),
  KEY `idx_parametre_cle` (`cle`),
  KEY `idx_parametre_categorie` (`categorie`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `parametres`
--
INSERT INTO `parametres` (`parametre_id`, `cle`, `valeur`, `type`, `categorie`, `description`, `modifiable`, `date_creation`, `date_modif`) VALUES ('1', 'nom_ecole', 'École Secondaire d\'Excellence', 'string', 'general', 'Nom officiel de l\'école', '1', '2026-01-23 15:23:06', '2026-01-23 15:23:06');
INSERT INTO `parametres` (`parametre_id`, `cle`, `valeur`, `type`, `categorie`, `description`, `modifiable`, `date_creation`, `date_modif`) VALUES ('2', 'adresse_ecole', '123 Avenue de l\'Éducation, Kinshasa', 'string', 'general', 'Adresse physique', '1', '2026-01-23 15:23:06', '2026-01-23 15:23:06');
INSERT INTO `parametres` (`parametre_id`, `cle`, `valeur`, `type`, `categorie`, `description`, `modifiable`, `date_creation`, `date_modif`) VALUES ('3', 'telephone_ecole', '+243 81 234 5678', 'string', 'general', 'Numéro de téléphone', '1', '2026-01-23 15:23:06', '2026-01-23 15:23:06');
INSERT INTO `parametres` (`parametre_id`, `cle`, `valeur`, `type`, `categorie`, `description`, `modifiable`, `date_creation`, `date_modif`) VALUES ('4', 'email_ecole', 'contact@ecole-excellence.cd', 'string', 'general', 'Email de contact', '1', '2026-01-23 15:23:06', '2026-01-23 15:23:06');
INSERT INTO `parametres` (`parametre_id`, `cle`, `valeur`, `type`, `categorie`, `description`, `modifiable`, `date_creation`, `date_modif`) VALUES ('5', 'devise_ecole', 'Savoir, Excellence, Discipline', 'string', 'general', 'Devise de l\'école', '1', '2026-01-23 15:23:06', '2026-01-23 15:23:06');
INSERT INTO `parametres` (`parametre_id`, `cle`, `valeur`, `type`, `categorie`, `description`, `modifiable`, `date_creation`, `date_modif`) VALUES ('6', 'annee_courante', '1', 'integer', 'academique', 'ID de l\'année scolaire courante', '1', '2026-01-23 15:23:06', '2026-01-23 15:23:06');
INSERT INTO `parametres` (`parametre_id`, `cle`, `valeur`, `type`, `categorie`, `description`, `modifiable`, `date_creation`, `date_modif`) VALUES ('7', 'delai_paiement', '15', 'integer', 'financier', 'Délai de paiement en jours', '1', '2026-01-23 15:23:06', '2026-01-23 15:23:06');
INSERT INTO `parametres` (`parametre_id`, `cle`, `valeur`, `type`, `categorie`, `description`, `modifiable`, `date_creation`, `date_modif`) VALUES ('8', 'taux_penalite', '5', 'integer', 'financier', 'Taux de pénalité pour retard', '1', '2026-01-23 15:23:06', '2026-01-23 15:23:06');
INSERT INTO `parametres` (`parametre_id`, `cle`, `valeur`, `type`, `categorie`, `description`, `modifiable`, `date_creation`, `date_modif`) VALUES ('9', 'limite_absence', '10', 'integer', 'disciplinaire', 'Limite d\'absences non justifiées', '1', '2026-01-23 15:23:06', '2026-01-23 15:23:06');
INSERT INTO `parametres` (`parametre_id`, `cle`, `valeur`, `type`, `categorie`, `description`, `modifiable`, `date_creation`, `date_modif`) VALUES ('10', 'seuil_reussite', '10', 'integer', 'academique', 'Note minimale pour réussir', '1', '2026-01-23 15:23:06', '2026-01-23 15:23:06');
INSERT INTO `parametres` (`parametre_id`, `cle`, `valeur`, `type`, `categorie`, `description`, `modifiable`, `date_creation`, `date_modif`) VALUES ('11', 'heure_debut_cours', '08:00:00', 'string', 'emploi_temps', 'Heure de début des cours', '1', '2026-01-23 15:23:06', '2026-01-23 15:23:06');
INSERT INTO `parametres` (`parametre_id`, `cle`, `valeur`, `type`, `categorie`, `description`, `modifiable`, `date_creation`, `date_modif`) VALUES ('12', 'heure_fin_cours', '16:00:00', 'string', 'emploi_temps', 'Heure de fin des cours', '1', '2026-01-23 15:23:06', '2026-01-23 15:23:06');
INSERT INTO `parametres` (`parametre_id`, `cle`, `valeur`, `type`, `categorie`, `description`, `modifiable`, `date_creation`, `date_modif`) VALUES ('13', 'frais_inscription', '50000', 'integer', 'financier', 'Frais d\'inscription par défaut', '1', '2026-01-23 15:23:06', '2026-01-23 15:23:06');
INSERT INTO `parametres` (`parametre_id`, `cle`, `valeur`, `type`, `categorie`, `description`, `modifiable`, `date_creation`, `date_modif`) VALUES ('14', 'frais_scolarite', '300000', 'integer', 'financier', 'Frais de scolarité par trimestre', '1', '2026-01-23 15:23:06', '2026-01-23 15:23:06');
INSERT INTO `parametres` (`parametre_id`, `cle`, `valeur`, `type`, `categorie`, `description`, `modifiable`, `date_creation`, `date_modif`) VALUES ('15', 'backup_auto', '1', 'boolean', 'system', 'Sauvegarde automatique activée', '1', '2026-01-23 15:23:06', '2026-01-23 15:23:06');
INSERT INTO `parametres` (`parametre_id`, `cle`, `valeur`, `type`, `categorie`, `description`, `modifiable`, `date_creation`, `date_modif`) VALUES ('16', 'backup_frequency', 'daily', 'string', 'system', 'Fréquence des sauvegardes', '1', '2026-01-23 15:23:06', '2026-01-23 15:23:06');

--
-- Structure de la table `parents`
--
DROP TABLE IF EXISTS `parents`;
CREATE TABLE `parents` (
  `parent_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `cin` varchar(20) DEFAULT NULL,
  `prenom` varchar(100) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `genre` enum('M','F') DEFAULT NULL,
  `profession` varchar(100) DEFAULT NULL,
  `entreprise` varchar(100) DEFAULT NULL,
  `telephone` varchar(20) NOT NULL,
  `telephone_bureau` varchar(20) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `est_principal` tinyint(1) DEFAULT 0,
  `date_creation` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`parent_id`),
  UNIQUE KEY `cin` (`cin`),
  KEY `idx_parent_nom` (`nom`,`prenom`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `parents`
--
--
-- Structure de la table `password_resets`
--
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `reset_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`reset_id`),
  UNIQUE KEY `token` (`token`),
  KEY `idx_password_resets_email` (`email`),
  KEY `idx_password_resets_token` (`token`),
  KEY `idx_password_resets_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `password_resets`
--
--
-- Structure de la table `professeurs`
--
DROP TABLE IF EXISTS `professeurs`;
CREATE TABLE `professeurs` (
  `professeur_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `matricule_prof` varchar(30) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `post_nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `date_naissance` date DEFAULT NULL,
  `lieu_naissance` varchar(100) DEFAULT NULL,
  `genre` enum('M','F','Autre') DEFAULT 'Autre',
  `nationalite` varchar(50) DEFAULT NULL,
  `telephone` varchar(20) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `specialite` varchar(100) DEFAULT NULL,
  `diplome` varchar(100) DEFAULT NULL,
  `date_embauche` date DEFAULT NULL,
  `statut` enum('actif','inactif','conge','retraite') DEFAULT 'actif',
  `type_contrat` enum('titulaire','contractuel','vacataire') DEFAULT NULL,
  `salaire_base` decimal(10,2) DEFAULT NULL,
  `banque` varchar(100) DEFAULT NULL,
  `numero_compte` varchar(50) DEFAULT NULL,
  `date_creation` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`professeur_id`),
  UNIQUE KEY `matricule_prof` (`matricule_prof`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_prof_matricule` (`matricule_prof`),
  KEY `idx_prof_statut` (`statut`),
  CONSTRAINT `professeurs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_admins` (`user_id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `professeurs`
--
INSERT INTO `professeurs` (`professeur_id`, `user_id`, `matricule_prof`, `nom`, `post_nom`, `prenom`, `date_naissance`, `lieu_naissance`, `genre`, `nationalite`, `telephone`, `email`, `adresse`, `specialite`, `diplome`, `date_embauche`, `statut`, `type_contrat`, `salaire_base`, `banque`, `numero_compte`, `date_creation`) VALUES ('1', '1', 'PROF-0001', 'calvin', 'mutimanwa', 'mukamba', '2006-01-05', 'kamituga', 'M', 'congolaise', '', NULL, NULL, NULL, NULL, NULL, 'actif', 'titulaire', '20000.00', NULL, NULL, '2026-01-24 04:40:35');
INSERT INTO `professeurs` (`professeur_id`, `user_id`, `matricule_prof`, `nom`, `post_nom`, `prenom`, `date_naissance`, `lieu_naissance`, `genre`, `nationalite`, `telephone`, `email`, `adresse`, `specialite`, `diplome`, `date_embauche`, `statut`, `type_contrat`, `salaire_base`, `banque`, `numero_compte`, `date_creation`) VALUES ('2', '2', 'PROF-20260126-2496', 'dd', '', 'dd', '0000-00-00', '', '', 'Congolaise', '+24 39 993 3730', '', '', '', '', '0000-00-00', 'actif', 'contractuel', '0.00', '', '', '2026-01-26 03:40:17');

--
-- Structure de la table `quittances`
--
DROP TABLE IF EXISTS `quittances`;
CREATE TABLE `quittances` (
  `quittance_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `numero_quittance` varchar(50) NOT NULL,
  `paiement_id` bigint(20) NOT NULL,
  `eleve_id` bigint(20) NOT NULL,
  `montant` decimal(10,2) NOT NULL,
  `date_quittance` datetime NOT NULL,
  `mode_paiement` enum('Espece','Virement','Cheque','Mobile','Carte') NOT NULL,
  `reference_banque` varchar(100) DEFAULT NULL,
  `caissier_id` bigint(20) NOT NULL,
  `statut` enum('valide','annule') DEFAULT 'valide',
  `date_creation` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`quittance_id`),
  UNIQUE KEY `numero_quittance` (`numero_quittance`),
  KEY `paiement_id` (`paiement_id`),
  KEY `eleve_id` (`eleve_id`),
  KEY `caissier_id` (`caissier_id`),
  KEY `idx_quittance_numero` (`numero_quittance`),
  KEY `idx_quittance_date` (`date_quittance`),
  CONSTRAINT `quittances_ibfk_1` FOREIGN KEY (`paiement_id`) REFERENCES `paiements` (`paiement_id`),
  CONSTRAINT `quittances_ibfk_2` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`eleve_id`),
  CONSTRAINT `quittances_ibfk_3` FOREIGN KEY (`caissier_id`) REFERENCES `user_admins` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `quittances`
--
--
-- Structure de la table `remember_tokens`
--
DROP TABLE IF EXISTS `remember_tokens`;
CREATE TABLE `remember_tokens` (
  `token_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `selector` varchar(32) NOT NULL,
  `hashed_token` varchar(64) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`token_id`),
  UNIQUE KEY `selector` (`selector`),
  KEY `idx_remember_tokens_user` (`user_id`),
  KEY `idx_remember_tokens_selector` (`selector`),
  KEY `idx_remember_tokens_expires` (`expires_at`),
  CONSTRAINT `remember_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_admins` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `remember_tokens`
--
--
-- Structure de la table `sanctions`
--
DROP TABLE IF EXISTS `sanctions`;
CREATE TABLE `sanctions` (
  `sanction_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `eleve_id` bigint(20) NOT NULL,
  `type_sanction` enum('avertissement','retenue','exclusion','convocation') NOT NULL,
  `gravite` enum('legere','moyenne','grave') DEFAULT 'legere',
  `date_sanction` date NOT NULL,
  `date_fin` date DEFAULT NULL,
  `motif` text NOT NULL,
  `mesures` text DEFAULT NULL,
  `sanctionne_par` bigint(20) NOT NULL,
  `statut` enum('actif','termine','annule') DEFAULT 'actif',
  `date_creation` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`sanction_id`),
  KEY `sanctionne_par` (`sanctionne_par`),
  KEY `idx_sanction_eleve` (`eleve_id`),
  KEY `idx_sanction_date` (`date_sanction`),
  CONSTRAINT `sanctions_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`eleve_id`) ON DELETE CASCADE,
  CONSTRAINT `sanctions_ibfk_2` FOREIGN KEY (`sanctionne_par`) REFERENCES `user_admins` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `sanctions`
--
--
-- Structure de la table `sections`
--
DROP TABLE IF EXISTS `sections`;
CREATE TABLE `sections` (
  `section_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `nom_section` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `couleur` varchar(7) DEFAULT '#3498db',
  `date_creation` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`section_id`),
  UNIQUE KEY `nom_section` (`nom_section`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `sections`
--
INSERT INTO `sections` (`section_id`, `nom_section`, `description`, `couleur`, `date_creation`) VALUES ('1', 'Scientifique', 'Section scientifique (Math, Physique, Chimie)', '#e74c3c', '2026-01-23 15:23:03');
INSERT INTO `sections` (`section_id`, `nom_section`, `description`, `couleur`, `date_creation`) VALUES ('2', 'Littéraire', 'Section littéraire (Littérature, Philosophie)', '#3498db', '2026-01-23 15:23:03');
INSERT INTO `sections` (`section_id`, `nom_section`, `description`, `couleur`, `date_creation`) VALUES ('3', 'Économique', 'Section économique (Économie, Gestion)', '#2ecc71', '2026-01-23 15:23:03');
INSERT INTO `sections` (`section_id`, `nom_section`, `description`, `couleur`, `date_creation`) VALUES ('4', 'Pédagogique', 'Section pédagogique', '#f39c12', '2026-01-23 15:23:03');

--
-- Structure de la table `student_parents`
--
DROP TABLE IF EXISTS `student_parents`;
CREATE TABLE `student_parents` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `eleve_id` bigint(20) NOT NULL,
  `parent_id` bigint(20) NOT NULL,
  `relation` varchar(50) NOT NULL,
  `est_responsable` tinyint(1) DEFAULT 0,
  `date_creation` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_eleve_parent` (`eleve_id`,`parent_id`,`relation`),
  KEY `idx_relation_eleve` (`eleve_id`),
  KEY `idx_relation_parent` (`parent_id`),
  CONSTRAINT `student_parents_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`eleve_id`) ON DELETE CASCADE,
  CONSTRAINT `student_parents_ibfk_2` FOREIGN KEY (`parent_id`) REFERENCES `parents` (`parent_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `student_parents`
--
--
-- Structure de la table `user_admins`
--
DROP TABLE IF EXISTS `user_admins`;
CREATE TABLE `user_admins` (
  `user_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uuid` char(36) DEFAULT uuid(),
  `identifiant` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mot_de_passe` varchar(255) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `role` enum('superadmin','admin','secretaire','gestionnaire','proviseur') DEFAULT 'secretaire',
  `permissions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`permissions`)),
  `dernier_login` datetime DEFAULT NULL,
  `statut` enum('actif','inactif','suspendu') DEFAULT 'actif',
  `date_creation` datetime DEFAULT current_timestamp(),
  `date_modif` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `identifiant` (`identifiant`),
  UNIQUE KEY `email` (`email`),
  UNIQUE KEY `uuid` (`uuid`),
  KEY `idx_user_identifiant` (`identifiant`),
  KEY `idx_user_role` (`role`),
  KEY `idx_user_statut` (`statut`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `user_admins`
--
INSERT INTO `user_admins` (`user_id`, `uuid`, `identifiant`, `email`, `mot_de_passe`, `nom`, `prenom`, `telephone`, `photo`, `role`, `permissions`, `dernier_login`, `statut`, `date_creation`, `date_modif`, `deleted_at`) VALUES ('1', 'a843f734-f85e-11f0-aeee-3ca82a82d546', 'superadmin', 'admin@ecole-excellence.cd', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Admin', 'Super', NULL, NULL, 'superadmin', '[\"*\"]', '2026-02-06 20:11:57', 'actif', '2026-01-23 15:23:07', '2026-02-06 20:11:57', NULL);
INSERT INTO `user_admins` (`user_id`, `uuid`, `identifiant`, `email`, `mot_de_passe`, `nom`, `prenom`, `telephone`, `photo`, `role`, `permissions`, `dernier_login`, `statut`, `date_creation`, `date_modif`, `deleted_at`) VALUES ('2', '212c2dcd-fa9b-11f0-8481-3ca82a82d546', 'prof_1', '', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'dd', 'dd', '+24 39 993 3730', NULL, 'admin', '[]', NULL, 'actif', '2026-01-26 03:40:17', '2026-02-06 22:43:33', NULL);

--
-- Structure de la table `user_sessions`
--
DROP TABLE IF EXISTS `user_sessions`;
CREATE TABLE `user_sessions` (
  `session_id` varchar(128) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` text DEFAULT NULL,
  `last_activity` int(11) NOT NULL,
  `expires_at` datetime NOT NULL,
  PRIMARY KEY (`session_id`),
  KEY `idx_sessions_user` (`user_id`),
  KEY `idx_sessions_expires` (`expires_at`),
  CONSTRAINT `user_sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user_admins` (`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `user_sessions`
--
--
-- Structure de la table `vue_eleves_complet`
--
DROP TABLE IF EXISTS `vue_eleves_complet`;
;

--
-- Données de la table `vue_eleves_complet`
--
--
-- Structure de la table `vue_performance_classes`
--
DROP TABLE IF EXISTS `vue_performance_classes`;
;

--
-- Données de la table `vue_performance_classes`
--
--
-- Structure de la table `vue_statistiques_financieres`
--
DROP TABLE IF EXISTS `vue_statistiques_financieres`;
;

--
-- Données de la table `vue_statistiques_financieres`
--
SET FOREIGN_KEY_CHECKS=1;
